function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}

let mic;
let amplitude;
let baseSize = 150;  // Taille de base de la sphère
let currentSize = baseSize;  // Taille actuelle de la sphère
let threshold = 0.05;  // Seuil pour déclencher les pics
let maxPicLength = 40;  // Longueur maximale des pics
let dampingFactor = 0.05; // Facteur d'amortissement des pics
let noiseFactor = 0.1;  // Facteur de bruit pour mouvement organique

let position;  // Position du centre de la sphère
let picData = [];  // Tableau pour stocker les pics

function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL); // Création du canevas en 3D
  mic = new p5.AudioIn();
  mic.start();
  amplitude = new p5.Amplitude();
  position = createVector(0, 0, 0);  // Position initiale de la sphère
  noFill();
  
  // Ajouter des lumières de base
  ambientLight(100);  // Lumière ambiante
  directionalLight(255, 255, 255, 0, -1, 1);  // Lumière directionnelle initiale
}

function draw() {
  background(0);

  // Récupérer le niveau sonore
  let level = mic.getLevel();

  // Ajuster la lumière en fonction du niveau sonore
  adjustLighting(level);

  // Générer des pics fluides si le niveau sonore dépasse le seuil
  if (level > threshold) {
    // Générer des pics de manière fluide
    generatePics(level);
  } else {
    // En silence, réduire progressivement la taille des pics
    reducePics();
    currentSize = baseSize;  // Maintenir la taille de la sphère stable
  }

  // Appliquer une couleur dynamique pour la sphère
  let colorValue = map(level, 0, 1, 100, 255);
  fill(colorValue, 100, 255 - colorValue);
  stroke(255, 100);  // Contours des pics

  // Centrer la sphère en 3D et appliquer des rotations
  translate(position.x, position.y, position.z);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);

  // Dessiner la sphère sans texture
  sphere(currentSize);

  // Dessiner les pics sans texture
  for (let pic of picData) {
    push();
    translate(pic.x, pic.y, pic.z);
    rotateX(pic.rotX);
    rotateY(pic.rotY);
    rotateZ(pic.rotZ);
    
    // Dessiner les pics sans texture
    cone(pic.length, 10);  // Longueur et largeur du pic
    pop();
  }
}

// Fonction pour ajuster la lumière en fonction du niveau sonore
function adjustLighting(level) {
  // Changer l'intensité de la lumière directionnelle en fonction du son
  let lightIntensity = map(level, 0, 1, 50, 255);  // L'intensité de la lumière varie en fonction du son

  // Ajuster la couleur de la lumière en fonction du son
  let r = map(level, 0, 1, 100, 255);  // La lumière devient plus rouge quand le son est fort
  let g = map(level, 0, 1, 100, 255);  // La lumière devient plus verte quand le son est fort
  let b = map(level, 0, 1, 255, 100);  // La lumière devient plus bleue quand le son est faible

  // Appliquer une lumière directionnelle dynamique
  directionalLight(r, g, b, 0, -1, 1);  // Lumière directionnelle avec des couleurs changeantes
  ambientLight(lightIntensity);  // Ajuster la lumière ambiante en fonction du son
}

// Fonction pour générer des pics de manière fluide sur la sphère
function generatePics(level) {
  // Modifier la taille de la sphère en fonction du son
  currentSize = map(level, 0, 1, baseSize, baseSize * 1.5);

  // Générer un nombre aléatoire de pics
  let numPics = int(map(level, 0, 1, 10, 50));  // Nombre de pics dépendant du niveau sonore

  // Ajouter de nouveaux pics en fonction du son
  for (let i = 0; i < numPics; i++) {
    let lat = random(-HALF_PI, HALF_PI);  // Latitude
    let lon = random(-PI, PI);  // Longitude

    // Calculer la position du pic sur la sphère
    let x = currentSize * cos(lat) * cos(lon);
    let y = currentSize * cos(lat) * sin(lon);
    let z = currentSize * sin(lat);

    // Vérifier si un pic existe déjà à cette position (pour éviter la superposition)
    let existingPic = picData.find(pic => dist(x, y, z, pic.x, pic.y, pic.z) < 5);
    if (existingPic) continue;

    // Créer un pic avec des caractéristiques aléatoires
    let pic = {
      x: x,
      y: y,
      z: z,
      length: 0,  // Initialement, les pics sont de taille 0
      maxLength: random(10, maxPicLength),  // Longueur maximale du pic
      rotX: random(TWO_PI),
      rotY: random(TWO_PI),
      rotZ: random(TWO_PI),
      growRate: random(0.1, 0.5),  // Vitesse de croissance des pics
    };

    // Ajouter le pic à la liste des pics
    picData.push(pic);
  }

  // Mettre à jour la longueur des pics en fonction du son
  for (let pic of picData) {
    pic.length = lerp(pic.length, pic.maxLength, pic.growRate);  // Interpolation pour une croissance fluide
  }
}

// Fonction pour réduire la taille des pics progressivement (damping)
function reducePics() {
  for (let pic of picData) {
    pic.length = lerp(pic.length, 0, dampingFactor);  // Amortir progressivement la longueur des pics
  }
}
